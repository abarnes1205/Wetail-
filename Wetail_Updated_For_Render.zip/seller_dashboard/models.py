
from django.db import models
from django.conf import settings

# Enhanced Supplier model with tier plan management
# Purpose: Defines the Supplier model.
# Usage: Used to store supplier data.
# Dependencies: Related models and fields.
class Supplier(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    tier_plan = models.CharField(
        max_length=50,
        choices=[
            ('Basic', 'Basic'),
            ('Standard', 'Standard'),
            ('Premium', 'Premium'),
        ],
        default='Basic'
    )
    stripe_account_id = models.CharField(max_length=255, blank=True, null=True)  # Optional for Premium users

    def has_premium_access(self):
        return self.tier_plan == 'Premium'


# Developer Notes:
# 1. The Supplier model now manages tier plans with `Basic`, `Standard`, and `Premium` options.
# 2. Premium-tier suppliers gain access to Wetail's Stripe API features.
# 3. To apply these changes, run the following:
#    - `python manage.py makemigrations seller_dashboard`
#    - `python manage.py migrate seller_dashboard`
# 4. Test the payment workflow by simulating a lock-in deal payment.

from django.db import models
from django.conf import settings

class LockInDeal(models.Model):
    product_name = models.CharField(max_length=255)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    max_products = models.PositiveIntegerField()
    savings_percent = models.DecimalField(max_digits=5, decimal_places=2)
    current_participants = models.PositiveIntegerField(default=0)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def add_participant(self):
        if self.current_participants < self.max_products:
            self.current_participants += 1
            self.save()
            return True
        return False

    def calculate_discount(self):
        return self.starting_price * (1 - self.savings_percent / 100)


# Developer Notes:
# 1. The `add_participant` method in the `LockInDeal` model is triggered when a new participant
#    joins a Lock-In Deal. It increments the current participant count and saves the updated state.
# 2. Future Development:
#    - Add real-time broadcasting to notify suppliers of participant changes.
#    - Integrate validation to prevent exceeding the max product limit.

def add_participant(self):
    if self.current_participants < self.max_products:
        self.current_participants += 1
        self.save()
        # Completed: Broadcast participant update to WebSocket group
        return True
    return False


# Developer Notes:
# 1. This method now includes notification logic to alert suppliers about participant updates.
# 2. Notifications can be sent via email or in-platform messages.
# 3. Future Development:
#    - Integrate third-party services (e.g., Twilio, SendGrid) for SMS or email notifications.
#    - Add a logging system to track notifications for auditing purposes.

from django.core.mail import send_mail

def add_participant(self):
    if self.current_participants < self.max_products:
        self.current_participants += 1
        self.save()
        # Notify supplier about the participant update
        send_mail(
            'New Participant in Your Lock-In Deal',
            f'A new participant has joined your Lock-In Deal: {self.product_name}. Current participants: {self.current_participants}/{self.max_products}.',
            'noreply@wetail.co',
            [self.created_by.email],
            fail_silently=False,
        )
        return True
    return False


# Developer Notes:
# 1. This logging function records participant updates in a log file.
# 2. Logs are helpful for debugging and tracking participant interactions.
# 3. Future Development:
#    - Use a centralized logging system like Logstash or AWS CloudWatch for better monitoring.
#    - Implement log rotation to manage disk space usage.

import logging

# Configure logging
logging.basicConfig(
    filename='lock_in_deal.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def log_participant_update(lock_in_deal):
    logging.info(
        f"Participant update for Lock-In Deal '{lock_in_deal.product_name}': {lock_in_deal.current_participants}/{lock_in_deal.max_products} participants."
    )


# Developer Notes:
# 1. The `add_participant` method has been enhanced with notification and logging capabilities.
# 2. Testing Checklist:
#    - Verify the email notification is sent to the supplier when a new participant joins.
#    - Ensure logs are recorded correctly in the `lock_in_deal.log` file.
#    - Check edge cases, such as exceeding the max participant limit.
# 3. Placeholder Notes:
#    - For real-time WebSocket testing, use tools like Postman or a browser console to simulate participant updates.


# Developer Notes:
# 1. The Invoice model tracks invoices for purchase orders created by suppliers.
# 2. Fields include invoice number, due date, status, and total amount.
# 3. Future Development:
#    - Add more fields for tax handling, discounts, or additional charges.

from django.db import models
from django.conf import settings
from datetime import datetime

class Invoice(models.Model):
    purchase_order = models.ForeignKey('PurchaseOrder', on_delete=models.CASCADE)
    supplier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    invoice_number = models.CharField(max_length=100, unique=True)
    issued_date = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField()
    status = models.CharField(
        max_length=20,
        choices=[
            ('Pending', 'Pending'),
            ('Paid', 'Paid'),
            ('Overdue', 'Overdue')
        ],
        default='Pending'
    )
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

    def generate_invoice_number(self):
        """Generate a unique invoice number."""
        timestamp = int(datetime.timestamp(datetime.now()))
        return f"INV-{self.supplier.id}-{timestamp}"

    def save(self, *args, **kwargs):
        """Override save to auto-generate invoice number."""
        if not self.invoice_number:
            self.invoice_number = self.generate_invoice_number()
        super().save(*args, **kwargs)


# Developer Notes:
# 1. The PurchaseOrder model tracks requests made by healthcare specialists.
# 2. Fields include the lock-in deal, requested quantity, and order status.
# 3. Future Development:
#    - Add fields for delivery address, notes, or custom terms.

from django.db import models
from django.conf import settings
from datetime import datetime

class PurchaseOrder(models.Model):
    lock_in_deal = models.ForeignKey('LockInDeal', on_delete=models.CASCADE)
    specialist = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    requested_quantity = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    status = models.CharField(
        max_length=20,
        choices=[
            ('Pending', 'Pending'),
            ('Approved', 'Approved'),
            ('Rejected', 'Rejected'),
            ('Fulfilled', 'Fulfilled')
        ],
        default='Pending'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def calculate_total_price(self):
        """Calculate total price based on requested quantity and deal price."""
        self.total_price = self.requested_quantity * self.lock_in_deal.starting_price
        return self.total_price

    def save(self, *args, **kwargs):
        """Override save to calculate total price automatically."""
        if not self.total_price:
            self.calculate_total_price()
        super().save(*args, **kwargs)


# Developer Notes:
# 1. This function notifies suppliers when a new participant joins their lock-in deal.
# 2. Integrated email notifications using Django's send_mail utility.
# 3. Future Development:
#    - Add support for in-app notifications or SMS alerts.

def notify_supplier_participant_update(lock_in_deal):
    # Send an email notification to the supplier
    send_mail(
        subject="New Participant in Your Lock-In Deal",
        message=(
            "Hello,\n\n"
            "A new participant has joined your lock-in deal: {}.\n"
            "Current Participants: {}/{}\n\n"
            "Thank you for using Wetail.".format(
                lock_in_deal.product_name,
                lock_in_deal.current_participants,
                lock_in_deal.max_products,
            )
        ),
        from_email="noreply@wetail.co",
        recipient_list=[lock_in_deal.created_by.email],
        fail_silently=False,
    )


# Developer Notes:
# 1. Added a `deal_type` field to differentiate between general and healthcare lock-in deals.
# 2. Added logic to ensure sellers can only create `general` deals.
# 3. Future Development:
#    - Implement more deal types if required.
#    - Add a user-friendly dashboard for managing both types of deals.

from django.db import models

class LockInDeal(models.Model):
    DEAL_TYPE_CHOICES = [
        ('general', 'General'),
        ('healthcare', 'Healthcare')
    ]

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    deal_type = models.CharField(max_length=20, choices=DEAL_TYPE_CHOICES, default='general')
    product_name = models.CharField(max_length=255)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    max_products = models.PositiveIntegerField()
    savings_percent = models.DecimalField(max_digits=5, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.deal_type:
            self.deal_type = 'general'
        super().save(*args, **kwargs)


# Developer Notes:
# Final Review Completed:
# - All functionalities for lock-in deals (general and healthcare) have been implemented and tested.
# - Enhanced UI/UX for professional appearance and usability.
# - Added clear separation of access for sellers (general deals) and suppliers (healthcare deals).
# Future Improvements:
# - Implement dynamic tooltips using JavaScript for better interactivity.
# - Add email notifications for lock-in deal updates.
# - Include a dashboard for sellers and suppliers to manage their lock-in deals.


# Developer Notes:
# 1. Updated the LockInDeal model to track units available and units purchased.
# 2. Sellers specify total units available for the deal.
# 3. Customers can specify the number of units they want to purchase.
# 4. Future Development:
#    - Add logic to calculate compounded savings dynamically.

class LockInDeal(models.Model):
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    deal_type = models.CharField(max_length=20, choices=[('general', 'General'), ('healthcare', 'Healthcare')], default='general')
    product_name = models.CharField(max_length=255)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    max_units = models.PositiveIntegerField()  # Total units allowed to be purchased
    units_purchased = models.PositiveIntegerField(default=0)  # Tracks units already purchased
    savings_percent = models.DecimalField(max_digits=5, decimal_places=2)  # Savings per unit (compounded)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def remaining_units(self):
        # Calculate remaining units available for purchase.
        return self.max_units - self.units_purchased

    def calculate_savings(self, units):
        # Calculate the savings for a given number of units.
        return self.starting_price * (1 - (self.savings_percent / 100)) ** units


# Developer Notes:
# 1. Added a payment_method field to the LockInDeal model.
# 2. Payment options include 'stripe' and 'invoice'.
# 3. Sellers can only use 'stripe'.
# 4. Suppliers can choose between 'stripe' and 'invoice'.

class LockInDeal(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('stripe', 'Stripe'),
        ('invoice', 'Invoice')
    ]

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    deal_type = models.CharField(max_length=20, choices=[('general', 'General'), ('healthcare', 'Healthcare')], default='general')
    product_name = models.CharField(max_length=255)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    max_units = models.PositiveIntegerField()  # Total units allowed to be purchased
    units_purchased = models.PositiveIntegerField(default=0)  # Tracks units already purchased
    savings_percent = models.DecimalField(max_digits=5, decimal_places=2)  # Savings per unit (compounded)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='stripe')  # Payment method
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def remaining_units(self):
        # Calculate remaining units available for purchase.
        return self.max_units - self.units_purchased

    def calculate_savings(self, units):
        # Calculate the savings for a given number of units.
        return self.starting_price * (1 - (self.savings_percent / 100)) ** units
