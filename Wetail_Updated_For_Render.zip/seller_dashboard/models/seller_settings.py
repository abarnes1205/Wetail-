from django.db import models

class SellerSettings(models.Model):
    seller = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    allow_multiple_purchases = models.BooleanField(default=False, help_text="Allow customers to buy multiple items in a Wetail Sale.")
    enable_flash_sales = models.BooleanField(default=False, help_text="Enable flash sales with the red running man icon.")
    enable_regular_sales = models.BooleanField(default=True, help_text="Allow regular product sales.")
    enable_wetail_sales = models.BooleanField(default=True, help_text="Enable time-based Wetail sales.")
