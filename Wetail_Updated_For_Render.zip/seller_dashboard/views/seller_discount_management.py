from django.shortcuts import render, redirect
from .models import SellerDiscountCode

def generate_seller_discount(request):
    if request.method == "POST":
        code = request.POST.get("code")
        discount_percentage = request.POST.get("discount_percentage")
        expiration_date = request.POST.get("expiration_date")
        usage_limit = request.POST.get("usage_limit")

        new_discount = SellerDiscountCode.objects.create(
            seller=request.user,
            code=code,
            discount_percentage=discount_percentage,
            expiration_date=expiration_date,
            is_active=True,
            usage_limit=usage_limit
        )
        new_discount.save()
        return redirect("seller_dashboard")

    return render(request, "seller_generate_discount.html")
