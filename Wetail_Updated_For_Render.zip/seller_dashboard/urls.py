
from django.urls import path
from .views import seller_analytics_dashboard

urlpatterns = [
    # Other URL patterns...
# Purpose: Defines the seller_analytics_dashboard URL pattern.
# Usage: Routes requests to the corresponding view for seller_analytics_dashboard.
    path('analytics/', seller_analytics_dashboard, name='seller_analytics_dashboard'),
]


# Developer Notes:
# 1. These URL routes connect the invoice views to the supplier dashboard.
# 2. Current Routes:
#    - Generate an invoice for a purchase order.
#    - List all invoices for a supplier.
# 3. Future Development:
#    - Add routes for viewing or downloading individual invoices.

from django.urls import path
from .views import generate_invoice, list_invoices

urlpatterns = [
    path('invoices/generate/<int:purchase_order_id>/', generate_invoice, name='generate_invoice'),
    path('invoices/', list_invoices, name='invoice_list'),
]


# Developer Notes:
# 1. These URL routes connect the purchase order views to the platform.
# 2. Current Routes:
#    - Submit a purchase order for a lock-in deal.
#    - List all purchase orders for a specialist.
# 3. Future Development:
#    - Add routes for viewing or editing individual purchase orders.

from .views import submit_purchase_order, list_purchase_orders

urlpatterns += [
    path('purchase-order/submit/<int:lock_in_deal_id>/', submit_purchase_order, name='submit_purchase_order'),
    path('purchase-orders/', list_purchase_orders, name='purchase_order_list'),
]
