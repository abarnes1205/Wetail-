from django.utils import timezone
from .models import WetailSale

def clone_expired_deals():
    expired_deals = WetailSale.objects.filter(is_active=False, clone_deal=True)
    
    for deal in expired_deals:
        next_clone_time = deal.sale_end_time + timezone.timedelta(days=deal.clone_frequency)
        if timezone.now() >= next_clone_time:
            new_deal = WetailSale.objects.create(
                product=deal.product,
                discount_percentage=deal.discount_percentage,
                max_participants=deal.max_participants,
                sale_end_time=timezone.now() + timezone.timedelta(days=deal.clone_frequency),
                clone_deal=deal.clone_deal,
                clone_frequency=deal.clone_frequency,
                is_active=True
            )
            deal.is_active = False  # Deactivate old deal
            deal.save()
