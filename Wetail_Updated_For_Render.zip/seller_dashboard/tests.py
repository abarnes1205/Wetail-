
from django.test import SimpleTestCase
from seller_dashboard.forms import LockInForm

class LockInFormValidationTests(SimpleTestCase):
    def test_form_validation_for_sellers(self):
        # Test that sellers see only 'stripe' as a payment method.
        class MockUser:
            is_staff = False  # Simulating a seller user
        form = LockInForm(user=MockUser())
        self.assertEqual(form.fields['payment_method'].choices, [('stripe', 'Stripe')])

    def test_form_validation_for_suppliers(self):
        # Test that suppliers see both 'stripe' and 'invoice' as payment methods.
        class MockUser:
            is_staff = True  # Simulating a supplier user
        form = LockInForm(user=MockUser())
        self.assertIn(('stripe', 'Stripe'), form.fields['payment_method'].choices)
        self.assertIn(('invoice', 'Invoice'), form.fields['payment_method'].choices)
