from django import forms
from .models import WetailSale

class WetailSaleForm(forms.ModelForm):
    clone_deal = forms.BooleanField(required=False, label="Enable Deal Cloning")
    clone_frequency = forms.IntegerField(required=False, min_value=1, max_value=30, label="Clone Frequency (Days)",
                                         help_text="Number of days before the deal is cloned again.")

    class Meta:
        model = WetailSale
        fields = ["discount_percentage", "max_participants", "sale_end_time", "clone_deal", "clone_frequency"]
