class LowStockChecker:
    def __init__(self):
        pass

    def check_stock(self):
        pass

    def send_alert(self):
        pass
