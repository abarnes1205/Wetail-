
from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('seller_dashboard', '0001_create_supplier_model'),  # Depends on the Supplier model migration
    ]

    operations = [
# Developer Note: Migration line lacks model name. Verify logic.
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255, unique=True)),
                ('parent', models.ForeignKey(
                    null=True, blank=True, to='seller_dashboard.Category', on_delete=models.CASCADE,
                    related_name='subcategories',
                )),
            ],
        ),
# Developer Note: Migration line lacks model name. Verify logic.
        migrations.CreateModel(
            name='Product',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255)),
                ('description', models.TextField(blank=True, null=True)),
                ('price', models.DecimalField(max_digits=10, decimal_places=2)),
                ('category', models.ForeignKey(
                    to='seller_dashboard.Category', on_delete=models.CASCADE, related_name='products',
                )),
                ('supplier', models.ForeignKey(
                    to='seller_dashboard.Supplier', on_delete=models.CASCADE, related_name='products',
                )),
            ],
        ),
    ]
