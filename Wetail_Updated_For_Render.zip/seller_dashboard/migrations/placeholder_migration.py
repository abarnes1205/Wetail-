
# Generated migration script for adding LockInDeal and SpecialistRequest models.

from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('auth', '0012_auto_20210601_1234'),  # Adjust this to match your existing migrations
    ]

    operations = [
        migrations.CreateModel(
            name='LockInDeal',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('product_name', models.CharField(max_length=255)),
                ('starting_price', models.DecimalField(decimal_places=2, max_digits=10)),
                ('max_products', models.PositiveIntegerField()),
                ('created_by', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.User')),
            ],
        ),
        migrations.CreateModel(
            name='SpecialistRequest',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('requested_quantity', models.PositiveIntegerField()),
                ('lock_in_deal', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='seller_dashboard.LockInDeal', related_name='specialist_requests')),
                ('requested_by', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.User')),
            ],
        ),
    ]
