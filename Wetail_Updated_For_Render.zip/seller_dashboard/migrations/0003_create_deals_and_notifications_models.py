
from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('seller_dashboard', '0002_create_product_and_category_models'),  # Depends on Product and Category models
    ]

    operations = [
# Developer Note: Migration line lacks model name. Verify logic.
        migrations.CreateModel(
            name='Deal',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255)),
                ('deal_type', models.CharField(
                    max_length=50,
                    choices=[
                        ('Time-Based', 'Time-Based'),
                        ('Flash Sale', 'Flash Sale'),
                        ('Group Savings', 'Group Savings'),
                    ],
                )),
                ('start_time', models.DateTimeField()),
                ('end_time', models.DateTimeField()),
                ('product', models.ForeignKey(
                    to='seller_dashboard.Product', on_delete=models.CASCADE, related_name='deals',
                )),
                ('supplier', models.ForeignKey(
                    to='seller_dashboard.Supplier', on_delete=models.CASCADE, related_name='deals',
                )),
            ],
        ),
# Developer Note: Migration line lacks model name. Verify logic.
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('message', models.TextField()),
                ('recipient', models.CharField(max_length=255)),  # Could be email or phone
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('deal', models.ForeignKey(
                    to='seller_dashboard.Deal', on_delete=models.CASCADE, related_name='notifications',
                )),
            ],
        ),
    ]
