
from django.db import migrations, models
from django.conf import settings

class Migration(migrations.Migration):

    dependencies = [
        ('auth', '0012_auto_20210101_0000'),  # Example dependency
    ]

    operations = [
# Developer Note: Migration line lacks model name. Verify logic.
        migrations.CreateModel(
            name='Supplier',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('tier_plan', models.CharField(
                    max_length=50,
                    choices=[
                        ('Basic', 'Basic'),
                        ('Standard', 'Standard'),
                        ('Premium', 'Premium'),
                    ],
                    default='Basic',
                )),
                ('stripe_account_id', models.CharField(max_length=255, blank=True, null=True)),
                ('user', models.OneToOneField(on_delete=models.CASCADE, to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]
