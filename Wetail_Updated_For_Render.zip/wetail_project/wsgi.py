

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'wetail_project.settings')

