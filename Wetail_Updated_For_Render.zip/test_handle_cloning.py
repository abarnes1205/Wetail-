import os
import django
from django.core.management import call_command



# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'wetail_project.settings')
django.setup()


# Run the handle_cloning command
call_command('handle_cloning')
