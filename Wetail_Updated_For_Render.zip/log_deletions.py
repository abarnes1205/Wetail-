
import os
import logging

logging.basicConfig(filename='/mnt/data/Wetail_Au_Optimal_Final_Fixed/file_deletion_log.txt', level=logging.INFO)

def track_file_deletion(instance, **kwargs):
    if hasattr(instance, 'file_field'):
        file_path = instance.file_field.path
        if os.path.exists(file_path):
            logging.info(f"Deleting file: {file_path} (Triggered by Django signal)")

from django.db.models.signals import post_delete
from django.dispatch import receiver
from main.models import Product

@receiver(post_delete, sender=Product)
def delete_product_file(sender, instance, **kwargs):
    track_file_deletion(instance)
