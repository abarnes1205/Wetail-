
# Project Name
This is a Django-based e-commerce platform with features like time-based group savings, seller dashboards, and API integrations.

## Features
- Time-based group savings deals.
- Separate dashboards for customers and sellers.
- Support for flash sales, regular sales, and Wetail Sales.
- Integration with APIs like Stripe and Shippo.

## Setup Instructions
1. Clone the repository.
2. Install dependencies using `pip install -r requirements.txt`.
3. Set up the `.env` file using `.env.example`.
4. Apply migrations using `python manage.py migrate`.
5. Run the server with `python manage.py runserver`.

## Contribution Guidelines
- Fork the repository and create a feature branch.
- Make sure your code passes all tests before submitting a PR.
