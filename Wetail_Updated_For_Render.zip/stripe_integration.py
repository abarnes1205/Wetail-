def process_payment():
    try:
        # Simulate payment processing logic
        payment_status = 'success'
        return payment_status
    except Exception as e:
        print(f'Error processing payment: {e}')
        return 'error'
