def simulate_load():
    """Function simulate_load: Describe purpose here."""
    for i in range(1000):
        print(f'Simulating request {i}')
