from django.core.cache import cache

def acquire_lock(lock_name, timeout=60):
    """Function acquire_lock: Describe purpose here."""
    return cache.add(lock_name, 'LOCKED', timeout)
