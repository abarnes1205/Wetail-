
from django.urls import path
from .views import check_onboarding, onboarding_view

# Developer Notes: Add routes for API credential management and Lock-In Form workflows if not present.
# Developer Notes:
# - Added routes for onboarding logic.
# - check_onboarding: Handles redirection based on onboarding completion.
# - onboarding_view: Displays onboarding process to users.

urlpatterns = [
    path('check_onboarding/', check_onboarding, name='check_onboarding'),
    path('onboarding/', onboarding_view, name='onboarding_view'),
]

from django.urls import path
from . import views

urlpatterns += [
    path('group-deal/create/', views.create_group_deal, name='create_group_deal'),
    path('group-deal/<int:group_id>/chat/', views.group_chat, name='group_chat'),
    path('suppliers/verified/', views.verified_suppliers, name='verified_suppliers'),
]

from django.urls import path
from . import views

urlpatterns += [
    path('group-deal/create/', views.create_group_deal, name='create_group_deal'),
    path('group-deal/<int:group_id>/chat/', views.group_chat, name='group_chat'),
    path('suppliers/verified/', views.verified_suppliers, name='verified_suppliers'),
    path('product/<int:product_id>/review/', views.submit_product_review, name='submit_product_review'),
    path('supplier/<int:supplier_id>/review/', views.submit_supplier_review, name='submit_supplier_review'),
]

from django.urls import path
from .views import get_payment_status_view, cancel_order_view

urlpatterns += [
    path('get-payment-status/<str:payment_intent_id>/', get_payment_status_view, name='get_payment_status'),
    path('cancel-order/<int:order_id>/', cancel_order_view, name='cancel_order'),
]

from django.urls import path
from .views import update_cancellation_timer

urlpatterns += [
    path('update-cancellation-timer/', update_cancellation_timer, name='update_cancellation_timer'),
]
