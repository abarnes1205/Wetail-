from selenium import webdriver

def run_automation():
    """Function run_automation: Describe purpose here."""
    driver = webdriver.Chrome()
    driver.get('https://example.com')
    driver.quit()
