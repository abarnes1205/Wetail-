import requests

def trigger_zapier_webhook(event_data):
    """Function trigger_zapier_webhook: Describe purpose here."""
    webhook_url = 'https://hooks.zapier.com/hooks/catch/example/'
    response = requests.post(webhook_url, json=event_data)
    return response.status_code
