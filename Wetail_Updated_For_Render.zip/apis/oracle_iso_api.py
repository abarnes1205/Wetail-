import requests

class OracleISOAPI:
    ORACLE_API_KEY = "YOUR_ORACLE_API_KEY_HERE"  # Placeholder
    ISO_API_KEY = "YOUR_ISO_API_KEY_HERE"  # Placeholder

    @staticmethod
    def verify_oracle_certification(cert_id):
        url = f"https://api.oracle.com/certifications/{cert_id}"
        headers = {"Authorization": f"Bearer {OracleISOAPI.ORACLE_API_KEY}"}
        response = requests.get(url, headers=headers)
        return response.json()

    @staticmethod
    def verify_iso_certification(cert_id):
        url = f"https://api.iso.org/certifications/{cert_id}"
        headers = {"Authorization": f"Bearer {OracleISOAPI.ISO_API_KEY}"}
        response = requests.get(url, headers=headers)
        return response.json()
