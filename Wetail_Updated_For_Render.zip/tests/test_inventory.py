
from django.test import TestCase
from app_name.models import ExampleModel

class TestInventory(TestCase):
    def setUp(self):
        self.example = ExampleModel.objects.create(name="Test Item")

    def test_add_inventory(self):
        ExampleModel.objects.create(name="New Item")
        self.assertEqual(ExampleModel.objects.count(), 2)

    def test_remove_inventory(self):
        self.example.delete()
        self.assertEqual(ExampleModel.objects.count(), 0)

    def test_inventory_limit(self):
        for _ in range(10):
            ExampleModel.objects.create(name="Bulk Item")
        self.assertEqual(ExampleModel.objects.count(), 11)  # Including the initial item
    