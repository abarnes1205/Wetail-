
from django.test import TestCase
from django.contrib.auth.models import User

class TestTwoFactorAuthentication(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="testuser", password="testpassword")

    def test_enable_2fa(self):
        # Example 2FA enabling logic (mocked)
        self.user.profile.two_factor_enabled = True
        self.user.profile.save()
        self.assertTrue(self.user.profile.two_factor_enabled)

    def test_disable_2fa(self):
        # Example 2FA disabling logic (mocked)
        self.user.profile.two_factor_enabled = False
        self.user.profile.save()
        self.assertFalse(self.user.profile.two_factor_enabled)
    