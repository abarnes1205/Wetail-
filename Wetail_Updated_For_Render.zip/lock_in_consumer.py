
from channels.generic.websocket import AsyncWebsocketConsumer
import json

class LockInFormConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.lock_in_group_name = f"lock_in_{self.scope['url_route']['kwargs']['lock_in_id']}"
        await self.channel_layer.group_add(
            self.lock_in_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.lock_in_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        data = json.loads(text_data)
        await self.channel_layer.group_send(
            self.lock_in_group_name,
            {
                'type': 'lock_in_update',
                'message': data['message']
            }
        )

    async def lock_in_update(self, event):
        message = event['message']
        await self.send(text_data=json.dumps({'message': message}))


# Developer Notes:
# 1. This WebSocket consumer enables real-time interaction for the Lock-In Deal feature.
# 2. It manages WebSocket connections, broadcasts messages to all participants in the same group,
#    and handles incoming messages such as updates from suppliers or specialists.
# 3. Future Development:
#    - Add more granular message handling (e.g., error messages, confirmations).
#    - Include authentication and permission checks for WebSocket connections.


# Developer Notes:
# 1. This consumer is responsible for real-time communication for the Lock-In Deal feature.
# 2. Current Functionality:
#    - Broadcasts participant updates to all connected clients.
# 3. Future Development:
#    - Add authentication to ensure only authorized users can send or receive updates.
#    - Include more event types, such as notifications for completed deals or new deal creations.


# Developer Notes:
# 1. Enhanced WebSocket consumer with error handling for invalid data and disconnections.
# 2. Future Development:
#    - Log errors for debugging and monitoring purposes.

async def receive(self, text_data):
    try:
        data = json.loads(text_data)
        if not isinstance(data.get('message'), dict):
            raise ValueError("Invalid message format.")
        await self.channel_layer.group_send(
            self.lock_in_group_name,
            {
                'type': 'lock_in_update',
                'message': data['message']
            }
        )
    except (json.JSONDecodeError, ValueError) as e:
        await self.send(text_data=json.dumps({'error': str(e)}))
