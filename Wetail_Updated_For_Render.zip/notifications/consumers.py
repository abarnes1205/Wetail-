class NotificationConsumer:
    def __init__(self):
        pass

    def connect(self):
        pass

    def disconnect(self):
        pass

    def receive(self, text_data):
        pass
