class SupplierNotification:
    def __init__(self):
        pass

    def notify(self, message):
        pass

    def log_notification(self):
        pass
