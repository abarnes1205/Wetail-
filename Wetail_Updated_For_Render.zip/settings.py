
import os


import dj_database_url
DATABASES = {
    'default': dj_database_url.config(default='sqlite:///db.sqlite3')
}
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.getenv('POSTGRES_DB', 'your_database_name'),
        'USER': os.getenv('POSTGRES_USER', 'your_database_user'),
        'PASSWORD': os.getenv('POSTGRES_PASSWORD', 'your_database_password'),
        'HOST': os.getenv('POSTGRES_HOST', 'localhost'),
        'PORT': os.getenv('POSTGRES_PORT', '5432'),
    }
}
