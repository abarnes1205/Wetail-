# Locust load testing script

from locust import HttpUser, task

class LoadTest(HttpUser):
    @task
    # Simulate concurrent users
    def load_homepage(self):
        self.client.get('/')

    @task
    def search_products(self):
        self.client.get('/search/?query=product')
