
// File: assets/js/lockinForm.js

document.getElementById('unitInput').addEventListener('input', function() {
    try {
        var unitInput = this;
        var errorMsg = document.getElementById('errorMsg');
        if (!errorMsg) {
            errorMsg = document.createElement('span');
            errorMsg.id = 'errorMsg';
            errorMsg.style.color = 'red';
            errorMsg.style.display = 'block';
            unitInput.parentNode.appendChild(errorMsg);
        }

        var units = parseInt(unitInput.value, 10);
        var startingPriceElem = document.getElementById('startingPrice');
        var discountPercentageElem = document.getElementById('discountPercentage');

        // Ensure dataset values are available
        if (!startingPriceElem || !discountPercentageElem) {
            errorMsg.textContent = "Error: Missing price or discount data.";
            return;
        }

        var startingPrice = parseFloat(startingPriceElem.dataset.price);
        var discountPercentage = parseFloat(discountPercentageElem.dataset.discount);

        // Validate inputs
        if (isNaN(units) || units < 0 || isNaN(startingPrice) || startingPrice < 0 || isNaN(discountPercentage) || discountPercentage < 0) {
            errorMsg.textContent = "Invalid input. Please enter a valid number.";
            return;
        }

        // Clear error message if input is valid
        errorMsg.textContent = "";

        // Calculate the total discount based on the percentage discount per unit
        var totalDiscount = startingPrice * (discountPercentage / 100) * units;
        var newPrice = startingPrice - totalDiscount;

        // Ensure new price doesn't go below zero
        newPrice = Math.max(newPrice, 0);

        // Update the price display element with the new price
        document.getElementById('priceDisplay').textContent = newPrice.toFixed(2);

    } catch (error) {
        console.error("An error occurred: ", error);
    }
});
