from django.shortcuts import render, redirect
from .models import UserAPIKey

def manage_api_keys(request):
    user_keys = UserAPIKey.objects.filter(user=request.user)
    return render(request, "manage_api_keys.html", {"api_keys": user_keys})

def add_api_key(request):
    if request.method == "POST":
        provider = request.POST.get("api_provider")
        key = request.POST.get("api_key")
        UserAPIKey.objects.create(user=request.user, api_provider=provider, api_key=key)
        return redirect("manage_api_keys")

    return render(request, "add_api_key.html")
