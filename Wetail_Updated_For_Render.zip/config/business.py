# Implement Google Analytics & Facebook Pixel
GOOGLE_ANALYTICS_ID = "UA-XXXXXXXXX-X"
FACEBOOK_PIXEL_ID = "XXXXXXXXXXXXXX"

# Setup Discount-Based Retargeting for Returning Users
def get_user_discount(user):
    if user.profile.returning_customer:
        return "10% OFF on your next purchase!"
    return None

# Add Apple Pay & Google Pay via Stripe
STRIPE_PAYMENT_METHODS = ["card", "apple_pay", "google_pay"]
