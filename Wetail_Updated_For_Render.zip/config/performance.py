# Enable Caching
from django.core.cache import cache

def get_cached_data(key, fallback_function, timeout=3600):
    data = cache.get(key)
    if not data:
        data = fallback_function()
        cache.set(key, data, timeout)
    return data

# Enable Lazy Loading for Product Images
# Add `loading="lazy"` to all product images in HTML templates

# Minify Static Files (CSS, JS)
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.ManifestStaticFilesStorage'

# Enable Compression Middleware
MIDDLEWARE.append('django.middleware.gzip.GZipMiddleware')
