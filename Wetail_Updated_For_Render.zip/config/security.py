# Implement Rate Limiting
from django.core.exceptions import PermissionDenied
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django_ratelimit.decorators import ratelimit

@method_decorator(ratelimit(key='ip', rate='5/m', method='POST', block=True), name='dispatch')
@method_decorator(never_cache, name='dispatch')
class SecureView(View):
    def get(self, request):
        return HttpResponse("Secure Endpoint")

# Enforce HTTPS
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Enable CSRF Protection
CSRF_COOKIE_SECURE = True

# Encrypt Stored Credentials
from django.contrib.auth.hashers import make_password
def encrypt_user_password(password):
    return make_password(password)
