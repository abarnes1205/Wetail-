from django.shortcuts import render
from .models import UserAPIKey

def admin_manage_api_access(request):
    all_api_keys = UserAPIKey.objects.all()
    return render(request, "admin_manage_api_access.html", {"api_keys": all_api_keys})
