from django.shortcuts import render, redirect
from .models import AdminDiscountCode

def generate_admin_discount(request):
    if request.method == "POST":
        code = request.POST.get("code")
        discount_percentage = request.POST.get("discount_percentage")
        expiration_date = request.POST.get("expiration_date")

        new_discount = AdminDiscountCode.objects.create(
            code=code,
            discount_percentage=discount_percentage,
            expiration_date=expiration_date,
            is_active=True
        )
        new_discount.save()
        return redirect("admin_dashboard")

    return render(request, "admin_generate_discount.html")
