from django.db import models

class StripePaymentMethod(models.Model):
    stripe_customer = models.ForeignKey(StripeCustomer, on_delete=models.CASCADE)
    payment_method_id = models.CharField(max_length=255, unique=True)
    last4 = models.CharField(max_length=4)
    brand = models.CharField(max_length=50)
    exp_month = models.IntegerField()
    exp_year = models.IntegerField()
    is_default = models.BooleanField(default=False)
