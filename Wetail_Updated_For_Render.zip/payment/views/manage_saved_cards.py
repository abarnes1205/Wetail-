def manage_saved_cards(request):
    customer = StripeCustomer.objects.get(user=request.user)
    saved_cards = StripePaymentMethod.objects.filter(stripe_customer=customer)
    return render(request, "manage_saved_cards.html", {"saved_cards": saved_cards})
