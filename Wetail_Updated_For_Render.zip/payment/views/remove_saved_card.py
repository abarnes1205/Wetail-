import stripe

def remove_saved_card(request, payment_method_id):
    customer = StripeCustomer.objects.get(user=request.user)

    # Detach the payment method from Stripe customer
    stripe.PaymentMethod.detach(payment_method_id)

    # Remove from database
    StripePaymentMethod.objects.filter(payment_method_id=payment_method_id).delete()

    return redirect("manage_saved_cards")
