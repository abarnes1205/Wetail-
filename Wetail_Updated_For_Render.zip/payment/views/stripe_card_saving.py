import stripe
from django.conf import settings
from django.shortcuts import render, redirect
from .models import StripeCustomer, StripePaymentMethod

stripe.api_key = settings.STRIPE_SECRET_KEY

def create_stripe_customer(user):
    customer = stripe.Customer.create(email=user.email)
    StripeCustomer.objects.create(user=user, stripe_customer_id=customer.id)
    return customer.id

def save_payment_method(request):
    if request.method == "POST":
        payment_method_id = request.POST.get("payment_method_id")
        
        # Ensure user has a Stripe customer ID
        customer, created = StripeCustomer.objects.get_or_create(user=request.user)
        if created:
            customer.stripe_customer_id = create_stripe_customer(request.user)
            customer.save()

        # Attach the payment method to the customer
        stripe.PaymentMethod.attach(payment_method_id, customer=customer.stripe_customer_id)
        stripe.Customer.modify(customer.stripe_customer_id, invoice_settings={"default_payment_method": payment_method_id})
        
        # Retrieve payment method details
        payment_method = stripe.PaymentMethod.retrieve(payment_method_id)

        # Save payment method in database
        StripePaymentMethod.objects.create(
            stripe_customer=customer,
            payment_method_id=payment_method.id,
            last4=payment_method.card.last4,
            brand=payment_method.card.brand,
            exp_month=payment_method.card.exp_month,
            exp_year=payment_method.card.exp_year,
            is_default=True
        )

        return redirect("customer_dashboard")

    return render(request, "save_payment_method.html")
