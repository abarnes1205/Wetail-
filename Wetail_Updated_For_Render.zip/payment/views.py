
from django.shortcuts import get_object_or_404
from stripe import Charge, Payout

# Purpose: Defines the process_lock_in_payment view.
# Usage: Handles process_lock_in_payment requests.
# Dependencies: Related models, forms, or templates.
def process_lock_in_payment(request, lock_in_deal_id):
    # Retrieve the lock-in deal and associated supplier
    lock_in_deal = get_object_or_404(LockInDeal, id=lock_in_deal_id)
    supplier = lock_in_deal.created_by

    # Check supplier's tier plan
    if supplier.supplier.has_premium_access():  # Ensure supplier is using Premium tier
        # Collect payment via Stripe
        charge = Charge.create(
            amount=lock_in_deal.starting_price * 100,  # Convert to cents
            currency="usd",
            source=request.POST.get("stripeToken"),  # Token from frontend
            description=f"Payment for Lock-In Deal {lock_in_deal.product_name}",
        )
        
        # Deduct platform fees and payout to supplier
        payout = Payout.create(
            amount=int(charge.amount * 0.9),  # Deduct 10% fee
            currency="usd",
            destination=supplier.stripe_account_id,  # Supplier Stripe account
            description=f"Payout for Lock-In Deal {lock_in_deal.product_name}",
        )

        return {"status": "success", "charge_id": charge.id, "payout_id": payout.id}
    else:
        return {"status": "failed", "message": "This feature is available only for Premium plan suppliers."}
