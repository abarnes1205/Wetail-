# from django.urls import path
# 
# 
# 
# app_name = 'payment'
# urlpatterns = 
# # @app.route('/create-checkout-session', methods=['POST'])
# path('create-checkout-session/', CreateCheckoutSession ,name='createcheckoutsession'),
# path('create-cart-checkout-session/', CreateCartCheckoutSession ,name='createcartcheckoutsession'),
# 
# path('stripe/webhook/', Webhook ,name='webhook'),
# path('success/', Success ,name='success'),
# path('cancel/', Cancel ,name='cancel'),
# path('buyer/deal/cancel/<str:order_id>/', BuyerCancelDeal,name='buyer_cancel_deal'),
# 
# 
