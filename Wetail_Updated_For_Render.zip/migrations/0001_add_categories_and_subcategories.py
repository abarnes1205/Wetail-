from django.db import migrations

def create_categories(apps, schema_editor):
    Category = apps.get_model('app_name', 'Category')
    categories = {
        'Apparel': ['T-Shirts', 'Shoes', 'Jackets'],
        'Electronics': ['Phones', 'Laptops', 'Tablets'],
        'Jewelry': ['Rings', 'Necklaces', 'Earrings', 'Bracelets', 'Watches'],
    }
    for category, subcategories in categories.items():
        category_obj = Category.objects.create(name=category)
        for subcategory in subcategories:
            Category.objects.create(name=subcategory, parent=category_obj)

class Migration(migrations.Migration):
    dependencies = [
        ('app_name', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(create_categories),
    ]
