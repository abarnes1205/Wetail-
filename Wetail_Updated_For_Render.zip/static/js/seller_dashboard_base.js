$(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200);  // Ensure semicolon for clarity
    if (
        $(this)
        .parent()
        .hasClass("active")
    ) {
        $(".sidebar-dropdown").removeClass("active");  // Ensure semicolon for clarity
        $(this)
            .parent()
            .removeClass("active");  // Ensure semicolon for clarity
    } else {
        $(".sidebar-dropdown").removeClass("active");  // Ensure semicolon for clarity
        $(this)
            .next(".sidebar-submenu")
            .slideDown(200);  // Ensure semicolon for clarity
        $(this)
            .parent()
            .addClass("active");  // Ensure semicolon for clarity
    }
});  // Ensure semicolon for clarity

$("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled");  // Ensure semicolon for clarity
});  // Ensure semicolon for clarity
$("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled");  // Ensure semicolon for clarity
});  // Ensure semicolon for clarity
if (screen.width <= 600) {
    document.getElementById("close-sidebar").click()
}