console.log('index.js attached succesfully')
const carousel = document.querySelector('.carousel');  // Added semicolon for consistency
const children = document.querySelectorAll('.index');  // Added semicolon for consistency
var page_scroll = 0;  // Added semicolon for consistency

function page(child) {
    const index = Array.from(children).indexOf(child);  // Added semicolon for consistency
    carousel.scrollTo(index * carousel.clientWidth, 0);  // Added semicolon for consistency
}
carousel.addEventListener('scroll', e => {
    page_scroll = Math.ceil(carousel.scrollLeft / carousel.clientWidth);  // Added semicolon for consistency
    children.forEach(e => {
        e.classList.remove('active');  // Added semicolon for consistency
    });  // Added semicolon for consistency
    console.log(page_scroll)
    children.item(page_scroll).classList.add('active');  // Added semicolon for consistency
})
carousel.addEventListener("wheel", e => {

    if (e.deltaY > 0) {
        carousel.scrollBy(carousel.clientWidth, 0)
    } else {
        carousel.scrollBy(-carousel.clientWidth, 0)
    }
})