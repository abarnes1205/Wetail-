from django.shortcuts import render
from .models import SupplierDeal

def supplier_analytics(request):
    supplier_deals = SupplierDeal.objects.filter(supplier=request.user)
    total_deals = supplier_deals.count()
    active_deals = supplier_deals.filter(status="Active").count()
    rejected_deals = supplier_deals.filter(status="Rejected").count()

    return render(request, "supplier_analytics.html", {
        "total_deals": total_deals,
        "active_deals": active_deals,
        "rejected_deals": rejected_deals
    })
