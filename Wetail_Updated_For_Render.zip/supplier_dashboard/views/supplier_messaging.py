from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import SupplierMessage

@login_required
def supplier_inbox(request):
    messages = SupplierMessage.objects.filter(receiver=request.user)
    return render(request, "supplier_inbox.html", {"messages": messages})

@login_required
def send_message(request):
    if request.method == "POST":
        receiver_id = request.POST.get("receiver_id")
        subject = request.POST.get("subject")
        body = request.POST.get("body")

        message = SupplierMessage.objects.create(
            sender=request.user,
            receiver_id=receiver_id,
            subject=subject,
            body=body
        )
        message.save()
        return redirect("supplier_inbox")

    return render(request, "supplier_send_message.html")
