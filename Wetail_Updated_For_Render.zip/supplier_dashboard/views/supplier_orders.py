from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Order

@login_required
def supplier_orders(request):
    orders = Order.objects.filter(supplier=request.user)
    return render(request, "supplier_orders.html", {"orders": orders})
