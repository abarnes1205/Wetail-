from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import SupplierDeal

@login_required
def create_supplier_deal(request):
    if request.method == "POST":
        title = request.POST.get("title")
        discount = request.POST.get("discount")
        min_order_quantity = request.POST.get("min_order_quantity")
        
        new_deal = SupplierDeal.objects.create(
            supplier=request.user,
            title=title,
            discount=discount,
            min_order_quantity=min_order_quantity,
            status="Pending Approval"
        )
        new_deal.save()
        return redirect("supplier_dashboard")

    return render(request, "supplier_create_deal.html")
