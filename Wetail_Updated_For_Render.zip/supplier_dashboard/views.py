from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import SupplierProduct, WetailSale
from .forms import SupplierProductForm, WetailSaleForm

@login_required
def supplier_dashboard(request):
    products = SupplierProduct.objects.filter(supplier=request.user.supplier_profile)
    return render(request, "supplier_dashboard.html", {"products": products})

@login_required
def create_product(request):
    if request.method == "POST":
        form = SupplierProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.supplier = request.user.supplier_profile
            product.save()
            return redirect("supplier_dashboard")
    else:
        form = SupplierProductForm()
    
    return render(request, "create_product.html", {"form": form})

@login_required
def create_wetail_sale(request, product_id):
    product = SupplierProduct.objects.get(id=product_id)
    if request.method == "POST":
        form = WetailSaleForm(request.POST)
        if form.is_valid():
            wetail_sale = form.save(commit=False)
            wetail_sale.product = product
            wetail_sale.save()
            return redirect("supplier_dashboard")
    else:
        form = WetailSaleForm()
    
    return render(request, "create_wetail_sale.html", {"form": form, "product": product})
