from django import forms
from .models import SupplierProduct, WetailSale

class SupplierProductForm(forms.ModelForm):
    class Meta:
        model = SupplierProduct
        fields = ["name", "description", "price", "stock_quantity", "is_active"]

class WetailSaleForm(forms.ModelForm):
    class Meta:
        model = WetailSale
        fields = ["discount_percentage", "max_participants", "sale_end_time"]
