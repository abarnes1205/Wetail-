from django.db import models
from django.contrib.auth.models import User

class SupplierProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="supplier_profile")
    company_name = models.CharField(max_length=255)
    is_verified = models.BooleanField(default=False)

class SupplierProduct(models.Model):
    supplier = models.ForeignKey(SupplierProfile, on_delete=models.CASCADE, related_name="products")
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.name

class WetailSale(models.Model):
    product = models.ForeignKey(SupplierProduct, on_delete=models.CASCADE, related_name="wetail_sales")
    discount_percentage = models.FloatField(default=0.0)
    max_participants = models.PositiveIntegerField()
    confirmed_participants = models.PositiveIntegerField(default=0)
    sale_end_time = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    def calculate_discounted_price(self):
        return self.product.price - (self.product.price * self.discount_percentage / 100)
