from django.db import models

class SupplierMessage(models.Model):
    sender = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name="received_messages")
    subject = models.CharField(max_length=255)
    body = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
