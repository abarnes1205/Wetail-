from django.db import models
from django.contrib.auth.models import User

class SupplierDeal(models.Model):
    supplier = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    discount = models.DecimalField(max_digits=5, decimal_places=2)
    min_order_quantity = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=[('Pending Approval', 'Pending Approval'), ('Active', 'Active'), ('Rejected', 'Rejected')], default='Pending Approval')
    created_at = models.DateTimeField(auto_now_add=True)
