from django.core.mail import send_mail
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class NotificationService:
    """Handles user notifications via email and system messages."""

    @staticmethod
    def send_email_notification(recipient_email, subject, message):
        """Sends an email notification to the specified recipient."""
        try:
            send_mail(
                subject,
                message,
                settings.DEFAULT_FROM_EMAIL,
                [recipient_email],
                fail_silently=False,
            )
            logger.info(f"Email notification sent to {recipient_email}.")
        except Exception as e:
            logger.error(f"Failed to send email to {recipient_email}: {str(e)}")

    @staticmethod
    def log_system_notification(user, message):
        """Logs a system notification for a given user."""
        try:
            # Example: Storing system notifications in a log file or database
            logger.info(f"Notification for {user}: {message}")
        except Exception as e:
            logger.error(f"Failed to log system notification: {str(e)}")

# Example Usage
if __name__ == "__main__":
    NotificationService.send_email_notification("test@example.com", "Test Subject", "This is a test notification.")
    NotificationService.log_system_notification("User123", "This is a system alert.")
