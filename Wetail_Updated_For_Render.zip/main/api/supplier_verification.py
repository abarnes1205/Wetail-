import requests

def verify_supplier_certification(supplier_id):
    supplier = Supplier.objects.get(id=supplier_id)
    api_url = "https://api.fda.gov/device/registration.json"
    response = requests.get(api_url, params={"supplier_name": supplier.company_name})
    if response.status_code == 200 and "results" in response.json():
        supplier.is_verified = True
    else:
        supplier.is_verified = False
    supplier.save()
