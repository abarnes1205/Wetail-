
# File upload validation
from django.core.exceptions import ValidationError

# Validate file type

def validate_file_type(file):
    valid_types = ['image/jpeg', 'image/png']
    if file.content_type not in valid_types:
        raise ValidationError('Unsupported file type.')

# Validate file size

def validate_file_size(file):
    max_size = 5 * 1024 * 1024  # 5 MB
    if file.size > max_size:
        raise ValidationError('File size exceeds the limit.')
