# from django.urls import path
# 
# app_name = 'main'
# urlpatterns = 
# path('', Home,name='home'),
# path('store/', Store,name='store'),
# path('store/filter/low-to-high/', FilterLowToHigh,name='store_lowtohigh'),
# path('store/filter/high-to-low/', FilterHighToLow,name='store_hightolow'),
# path('store/filter/highest-savings/', FilterHighestSaving,name='store_highestsavings'),
# path('store/category/food/', CategoryFood,name='store_food'),
# path('store/category/service/', CategoryService,name='store_service'),
# path('store/category/health-and-fitness/', CategoryHealthAndFitness,name='store_healthandfitness'),
# path('store/category/electronics/', CategoryElectronics,name='store_electronics'),
# path('store/category/automotives/', CategoryAutomotives,name='store_automotives'),
# path('store/search/', SearchResults,name='search'),
# path('store/add-to-cart/<str:id>/', AddToCart,name='add_to_cart'),
# path('store/remove-from-cart/<str:id>/', RemoveFromCart,name='remove_from_cart'),
# path('contact/', Contact,name='contact'),
# path('user/login/', UserLogin,name='userlogin'),
# path('verify/email/', VerifyEmailCustomer,name='verifyemailcustomer'),
# path('verify/email/affiliates/', VerifyEmailAffiliates,name='verifyemailaffiliates'),
# path('verify/email-otp/', VerifyEmailOtp,name='verifyemailotp'),
# path('verify/email-otp/affiliates/', VerifyEmailOtpAffiliates,name='verifyemailotpaffiliates'),
# path('verify/email-otp/resend/', VerifyEmailOtpResend,name='verifyemailotpresend'),
# path('verify/change-email/', ChangeEmail,name='changemail'),
# path('user/signup/', UserSignup,name='usersignup'),
# path('user/logout/', Logout,name='logout'),
# path('seller/signup/', SellerSignup,name='sellersignup'),
# path('cart/', Cart,name='cart'),
# path('myorder/', MyOrder,name='myorder'),
# path('myorder/completed/', MyOrderCompleted,name='myordercompleted'),
# path('product/<str:id>/', ProductDetail,name='product'),
# path('customer/save-address/', CustomerSaveAddress,name='customer_save_address'),
# path('user/settings/', UserSettings,name='user_settings'),
# path('test-data-add/', AddData),
# path('test-data-sub/', SubData),
# 
# 
# 
# # Healthcare Procurement URLs
# 
# 
# urlpatterns += 
# path('supplier-onboarding/', views.supplier_onboarding, name='supplier_onboarding'),
# path'procurement-specialist-registration/', views.procurement_specialist_registration,
# name='procurement_specialist_registration',
# path('healthcare-product-management/', views.healthcare_product_management, name='healthcare_product_management'),
# 
# 
# # Login and Unauthorized Access URLs
# 
# urlpatterns += 
# path('login/', views.custom_login, name='login'),
# path('unauthorized/', views.unauthorized_access, name='unauthorized'),
# 
# 
# # Added product search URL
# from . import views
# 
# urlpatterns += [
#     path('search/', views.product_search, name='product_search'),
# ]
