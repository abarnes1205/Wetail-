from main.models import Category

categories = {
    "Electronics": ["Mobile Phones", "Laptops", "Headphones", "Cameras", "Wearables", "Gaming Consoles"],
    "Jewelry": ["Necklaces", "Bracelets", "Earrings", "Rings", "Watches", "Luxury Jewelry"],
    "Pet Supplies": ["Pet Food", "Pet Toys", "Pet Beds", "Grooming Tools", "Collars & Leashes", "Aquariums"],
    "Apparel": [
        "Men's Clothing - T-Shirts", "Men's Clothing - Polo Shirts", "Men's Clothing - Dress Shirts", "Men's Clothing - Hoodies & Sweatshirts", 
        "Men's Clothing - Jackets & Blazers", "Men's Clothing - Jeans", "Men's Clothing - Dress Pants", "Men's Clothing - Shorts", 
        "Men's Clothing - Activewear", "Men's Clothing - Underwear & Socks", "Men's Clothing - Suits & Formal Wear", 
        "Men's Clothing - Outerwear", "Men's Clothing - Sleepwear & Loungewear", "Men's Clothing - Workwear & Uniforms",
        "Women's Clothing - T-Shirts & Tops", "Women's Clothing - Blouses", "Women's Clothing - Sweaters & Cardigans", 
        "Women's Clothing - Hoodies & Sweatshirts", "Women's Clothing - Jackets & Coats", "Women's Clothing - Jeans & Jeggings", 
        "Women's Clothing - Leggings & Tights", "Women's Clothing - Skirts & Dresses", "Women's Clothing - Pants & Trousers", 
        "Women's Clothing - Activewear", "Women's Clothing - Lingerie & Nightwear", "Women's Clothing - Maternity Wear", 
        "Women's Clothing - Swimwear", "Women's Clothing - Formal & Party Wear",
        "Kids' Clothing - T-Shirts & Tops", "Kids' Clothing - Hoodies & Sweatshirts", "Kids' Clothing - Jackets & Coats", 
        "Kids' Clothing - Dresses & Skirts", "Kids' Clothing - Jeans & Pants", "Kids' Clothing - Leggings & Joggers", 
        "Kids' Clothing - Shorts", "Kids' Clothing - School Uniforms", "Kids' Clothing - Activewear", "Kids' Clothing - Baby Clothes", 
        "Kids' Clothing - Footwear", "Kids' Clothing - Accessories"
    ],
    "Health and Fitness": ["Supplements", "Exercise Equipment", "Wellness Products", "Personal Care", "Medical Devices", "Yoga & Meditation"],
    "Service": ["Home Services", "Automotive Services", "Consulting", "Freelancing", "Repair & Maintenance", "Personal Coaching"],
    "Healthcare Procurement": [
        "Medical Equipment", "Surgical Instruments", "Hospital Beds & Furniture", "Diagnostic Devices", "Laboratory Supplies", 
        "Personal Protective Equipment (PPE)", "Wound Care Products", "Orthopedic Supplies", "Dental Supplies", "IV & Injection Supplies", 
        "Respiratory Equipment", "Mobility Aids", "Sterilization & Disinfection", "First Aid & Emergency Care", "Veterinary Medical Supplies",
        "Linens - Hospital Bed Sheets", "Linens - Patient Gowns", "Linens - Surgical Drapes", "Linens - Pillowcases & Blankets", 
        "Linens - Towels & Washcloths", "Linens - Disposable Linens"
    ]
}

for category, subcategories in categories.items():
    parent_category, created = Category.objects.get_or_create(name=category, parent=None)
    for subcategory in subcategories:
        Category.objects.get_or_create(name=subcategory, parent=parent_category)
