from django.core.mail import send_mail

def send_order_notification(user_email, order_status):
    subject = f"Order Update: {order_status}"
    message = f"Your order status has been updated to: {order_status}. Thank you for shopping with Wetail!"
    send_mail(subject, message, 'support@wetail.co', [user_email])
