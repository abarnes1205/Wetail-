from django.db import models

class HealthcareProcurementVerification(models.Model):
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    organization_name = models.CharField(max_length=255)
    organization_address = models.CharField(max_length=255)
    organization_phone = models.CharField(max_length=20)
    hr_contact_name = models.CharField(max_length=255)
    hr_contact_email = models.EmailField()
    verification_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Verified', 'Verified'), ('Rejected', 'Rejected')], default='Pending')

    def verify(self):
        self.verification_status = 'Verified'
        self.save()
