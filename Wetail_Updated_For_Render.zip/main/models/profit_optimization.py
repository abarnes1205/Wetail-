from django.db import models

class ProfitOptimization(models.Model):
    seller = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    savings_percentage = models.DecimalField(max_digits=5, decimal_places=2)
    optimized_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    def calculate_optimized_price(self):
        self.optimized_price = self.starting_price * (1 - (self.savings_percentage / 100))
        self.save()
