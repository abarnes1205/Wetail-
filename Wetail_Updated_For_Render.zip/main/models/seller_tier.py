from django.db import models

class SellerTier(models.Model):
    seller = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    tier_level = models.CharField(max_length=20, choices=[('Basic', 'Basic'), ('Standard', 'Standard'), ('Premium', 'Premium')], default='Basic')
    monthly_fee = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    transaction_fee_percentage = models.DecimalField(max_digits=4, decimal_places=2, default=12.00)  # 12% for Basic, 8% for Standard, 5% for Premium

    def update_tier(self, new_tier):
        if new_tier == 'Standard':
            self.monthly_fee = 14.00
            self.transaction_fee_percentage = 8.00
        elif new_tier == 'Premium':
            self.monthly_fee = 49.00
            self.transaction_fee_percentage = 5.00
        else:
            self.monthly_fee = 0.00
            self.transaction_fee_percentage = 12.00
        self.tier_level = new_tier
        self.save()
