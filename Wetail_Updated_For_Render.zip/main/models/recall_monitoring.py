from django.db import models

class ProductRecall(models.Model):
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    recall_reason = models.TextField()
    recall_date = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    def resolve_recall(self):
        self.resolved = True
        self.save()
