from django.db import models

class ProductSampleRequest(models.Model):
    hospital = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    supplier = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name="sample_requests")
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=[('Requested', 'Requested'), ('Shipped', 'Shipped'), ('Reviewed', 'Reviewed')], default='Requested')
    feedback = models.TextField(blank=True, null=True)

    def update_status(self, new_status, feedback=None):
        self.status = new_status
        if feedback:
            self.feedback = feedback
        self.save()
