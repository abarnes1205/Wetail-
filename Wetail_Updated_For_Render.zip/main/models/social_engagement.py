from django.db import models

class SocialEngagement(models.Model):
    customer = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    shared_deal_count = models.IntegerField(default=0)
    friends_referred = models.IntegerField(default=0)
