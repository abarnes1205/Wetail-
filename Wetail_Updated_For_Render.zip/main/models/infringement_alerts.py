from django.db import models

class InfringementAlert(models.Model):
    seller = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    alert_reason = models.TextField()
    alert_date = models.DateTimeField(auto_now_add=True)
    reviewed = models.BooleanField(default=False)

    def mark_reviewed(self):
        self.reviewed = True
        self.save()
