from django.db import models

class OrderTracking(models.Model):
    order = models.OneToOneField('Order', on_delete=models.CASCADE)
    tracking_number = models.CharField(max_length=50, unique=True)
    shipment_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Shipped', 'Shipped'), ('Delivered', 'Delivered')], default='Pending')
    last_updated = models.DateTimeField(auto_now=True)

    def update_status(self, status):
        self.shipment_status = status
        self.save()
