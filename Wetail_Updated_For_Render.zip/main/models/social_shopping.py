from django.db import models

class GroupBuy(models.Model):
    deal = models.ForeignKey('Deal', on_delete=models.CASCADE)
    created_by = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    participants = models.ManyToManyField('auth.User', related_name='group_buy_participants')
