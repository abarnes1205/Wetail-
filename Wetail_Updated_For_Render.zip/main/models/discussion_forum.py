from django.db import models

class DiscussionThread(models.Model):
    topic = models.CharField(max_length=255)
    created_by = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

class DiscussionPost(models.Model):
    thread = models.ForeignKey('DiscussionThread', on_delete=models.CASCADE, related_name="posts")
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
