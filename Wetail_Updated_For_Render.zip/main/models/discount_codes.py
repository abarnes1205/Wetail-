from django.db import models

class DiscountCode(models.Model):
    code = models.CharField(max_length=20, unique=True)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2)
    expiration_date = models.DateTimeField()
    created_by_admin = models.BooleanField(default=True)

    def is_valid(self):
        return self.expiration_date > timezone.now()
