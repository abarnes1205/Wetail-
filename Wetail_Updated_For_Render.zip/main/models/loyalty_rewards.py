from django.db import models

class LoyaltyRewards(models.Model):
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    purchase_count = models.IntegerField(default=0)
    eligible_for_reward = models.BooleanField(default=False)

    def check_rewards(self):
        if self.purchase_count in [3, 4, 5]:
            self.eligible_for_reward = True  # Free shipping reward
        elif self.purchase_count % 20 == 0:
            self.eligible_for_reward = True  # 30% discount reward
        else:
            self.eligible_for_reward = False
        self.save()
