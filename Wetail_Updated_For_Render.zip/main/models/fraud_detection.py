from django.db import models

class Transaction(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Flagged', 'Flagged')], default='Pending')

    def check_for_fraud(self):
        if self.amount > 5000:  # Example threshold for fraud check
            self.status = "Flagged"
            self.save()
