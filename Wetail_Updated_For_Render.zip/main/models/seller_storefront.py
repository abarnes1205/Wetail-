from django.db import models

class SellerProfile(models.Model):
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE)
    storefront_banner = models.ImageField(upload_to='storefront_banners/', null=True, blank=True)
    storefront_color_theme = models.CharField(max_length=20, default="default_theme")
