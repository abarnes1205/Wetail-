from django.db import models

class RefundDisputeTracking(models.Model):
    refund_request = models.OneToOneField('RefundTransaction', on_delete=models.CASCADE)
    dispute_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Resolved', 'Resolved')], default='Pending')
    admin_notes = models.TextField(blank=True, null=True)
    last_updated = models.DateTimeField(auto_now=True)

    def resolve_dispute(self, notes):
        self.dispute_status = "Resolved"
        self.admin_notes = notes
        self.save()
