from django.db import models

class AdminLoginAttempt(models.Model):
    admin_user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    attempt_date = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField(default=False)
