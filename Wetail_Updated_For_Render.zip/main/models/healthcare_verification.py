from django.db import models
from django.contrib.auth.models import User
from django.core.validators import FileExtensionValidator
from django.core.mail import send_mail
from django.conf import settings

class HealthcareVerification(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="healthcare_verification")
    license_document = models.FileField(upload_to="healthcare_licenses/",
                                        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'jpg', 'png'])])
    status = models.CharField(max_length=20, choices=[("Pending", "Pending"), ("Verified", "Verified"), ("Rejected", "Rejected")], default="Pending")
    submitted_at = models.DateTimeField(auto_now_add=True)

    def approve(self):
        self.status = "Verified"
        self.save()
        # Send email confirmation to the user
        send_mail(
            "Healthcare Procurement Verification Approved",
            "Your verification request has been approved. You now have access to Healthcare Procurement.",
            settings.DEFAULT_FROM_EMAIL,
            [self.user.email],
            fail_silently=False,
        )

    def reject(self):
        self.status = "Rejected"
        self.save()
        # Send rejection email to the user
        send_mail(
            "Healthcare Procurement Verification Rejected",
            "Your verification request has been rejected. Please resubmit with correct credentials.",
            settings.DEFAULT_FROM_EMAIL,
            [self.user.email],
            fail_silently=False,
        )
