from django.db import models

class CustomerBehavior(models.Model):
    customer = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    cart_abandonment_count = models.IntegerField(default=0)
    deal_participation_count = models.IntegerField(default=0)
    last_active_date = models.DateTimeField(auto_now=True)
