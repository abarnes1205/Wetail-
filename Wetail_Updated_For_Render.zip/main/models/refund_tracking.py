from django.db import models

class RefundTransaction(models.Model):
    transaction = models.OneToOneField('Transaction', on_delete=models.CASCADE)
    refund_requested = models.BooleanField(default=False)
    refund_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Denied', 'Denied')], default='Pending')

    def approve_refund(self):
        self.refund_status = "Approved"
        self.transaction.status = "Refunded"
        self.transaction.save()
        self.save()
