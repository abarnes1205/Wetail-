from django.db import models

class SupplierAudit(models.Model):
    supplier = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    audit_type = models.CharField(max_length=50, choices=[('On-Site', 'On-Site'), ('Virtual', 'Virtual')])
    audit_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Completed', 'Completed'), ('Failed', 'Failed')])
    audit_notes = models.TextField(blank=True, null=True)
    requested_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True, related_name="audit_requests")
    audit_date = models.DateTimeField(auto_now_add=True)

    def complete_audit(self, status, notes):
        self.audit_status = status
        self.audit_notes = notes
        self.save()
