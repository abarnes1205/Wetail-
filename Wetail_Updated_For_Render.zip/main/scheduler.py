from django_q.tasks import schedule
from django_q.models import Schedule



# Schedule the handle_cloning command to run every hour
schedule
name='Clone Expired Deals',
func='main.management.commands.handle_cloning.Command.handle',
schedule_type=Schedule.HOURLY,

