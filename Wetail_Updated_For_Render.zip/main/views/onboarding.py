from django.shortcuts import render, redirect

def first_time_user_guide(request):
    if not request.session.get('onboarded', False):
        return render(request, "onboarding_guide.html")
    return redirect("home")
