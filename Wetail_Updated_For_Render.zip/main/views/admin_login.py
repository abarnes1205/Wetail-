from django.core.mail import send_mail

def admin_login_request(user_email, admin_name):
    verification_code = "8668"
    if admin_name and user_email:
        send_mail(
            'Wetail Admin Access Request',
            f'{admin_name} is requesting access to the admin panel. Approve or deny access.',
            'no-reply@wetail.com',
            ['altonbarnes11@gmail.com']
        )
