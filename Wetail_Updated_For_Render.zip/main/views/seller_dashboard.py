from django.shortcuts import render
from .models import ProfitOptimization

def seller_dashboard(request):
    optimizations = ProfitOptimization.objects.filter(seller=request.user)
    return render(request, "seller_dashboard.html", {"optimizations": optimizations})
