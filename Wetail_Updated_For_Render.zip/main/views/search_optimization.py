from django.shortcuts import render
from .models import Product

def search_products(request):
    query = request.GET.get('query', '')
    category = request.GET.get('category', '')
    price_range = request.GET.get('price_range', '')
    
    results = Product.objects.filter(name__icontains=query)
    
    if category:
        results = results.filter(category=category)
    if price_range:
        min_price, max_price = map(int, price_range.split('-'))
        results = results.filter(price__gte=min_price, price__lte=max_price)
    
    return render(request, "search_results.html", {"results": results})
