from django.db.models import Q

def search_products(query):
    return Product.objects.filter(
        Q(name__icontains=query) | Q(description__icontains=query) | Q(category__name__icontains=query)
    )
