from django.shortcuts import render
from .models import BundleDeal

def create_bundle_deal(request):
    return render(request, "create_bundle.html", {"categories": ['Electronics', 'Apparel', 'Health & Fitness', 'Jewelry']})
