from django.shortcuts import redirect

def initiate_payment(request, payment_method):
    if payment_method == "google_pay":
        return redirect("google_pay_gateway")
    elif payment_method == "apple_pay":
        return redirect("apple_pay_gateway")
    else:
        return redirect("standard_payment_gateway")
