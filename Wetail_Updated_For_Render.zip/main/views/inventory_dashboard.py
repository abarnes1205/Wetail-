from django.shortcuts import render
from .models import Inventory

def inventory_dashboard(request):
    inventory = Inventory.objects.filter(seller=request.user)
    return render(request, "inventory_dashboard.html", {"inventory": inventory})
