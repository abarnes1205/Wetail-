from django.shortcuts import redirect

def one_click_buy(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    order = Order.objects.create(user=request.user, product=product, status="Pending")
    return redirect("checkout_page", order_id=order.id)
