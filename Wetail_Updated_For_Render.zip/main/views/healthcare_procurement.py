from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import HealthcareVerification

@login_required
def healthcare_procurement_view(request):
    if not hasattr(request.user, "healthcare_verification") or request.user.healthcare_verification.status != "Verified":
        return redirect("verification_required")

    categories = ["Medical Equipment", "Surgical Instruments", "Hospital Beds & Furniture", "Diagnostic Devices", 
                  "Laboratory Supplies", "Personal Protective Equipment (PPE)", "Wound Care Products", "Orthopedic Supplies", 
                  "Dental Supplies", "IV & Injection Supplies", "Respiratory Equipment", "Mobility Aids", 
                  "Sterilization & Disinfection", "First Aid & Emergency Care", "Veterinary Medical Supplies", "Linens"]
    
    return render(request, "healthcare_procurement.html", {"categories": categories})
