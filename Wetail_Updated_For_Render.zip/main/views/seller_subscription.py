from django.shortcuts import render
from .models import SellerSubscription

def seller_subscription_view(request):
    subscription = SellerSubscription.objects.get(seller=request.user)
    return render(request, "seller_subscription.html", {"subscription": subscription, "plans": ['Basic', 'Standard', 'Premium']})
