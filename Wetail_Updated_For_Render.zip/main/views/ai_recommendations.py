from django.shortcuts import render
from .models import Product

def personalized_recommendations(request):
    recommended_products = Product.objects.order_by('?')[:5]  # Randomized recommendations (AI can replace this)
    return render(request, "recommendations.html", {"recommended_products": recommended_products})
