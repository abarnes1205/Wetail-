from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import UserProfile

@login_required
def enable_2fa(request):
    user_profile = UserProfile.objects.get(user=request.user)
    user_profile.has_2fa_enabled = True
    user_profile.save()
    return redirect("dashboard")

@login_required
def disable_2fa(request):
    user_profile = UserProfile.objects.get(user=request.user)
    user_profile.has_2fa_enabled = False
    user_profile.save()
    return redirect("dashboard")
