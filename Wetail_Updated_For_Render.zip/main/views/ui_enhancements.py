from django.shortcuts import render

def product_detail_view(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, "product_detail.html", {
        "product": product,
        "enable_image_zoom": True,
        "enable_360_view": True
    })
