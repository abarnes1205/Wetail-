from django.shortcuts import render
from .models import ProductPerformance

def seller_analytics_view(request):
    filter_param = request.GET.get('filter', 'all')
    if filter_param == 'top_sellers':
        performance_data = ProductPerformance.objects.filter(seller=request.user).order_by('-sales')[:10]
    elif filter_param == 'low_performance':
        performance_data = ProductPerformance.objects.filter(seller=request.user).order_by('sales')[:10]
    else:
        performance_data = ProductPerformance.objects.filter(seller=request.user)

    return render(request, "seller_analytics.html", {"performance_data": performance_data})
