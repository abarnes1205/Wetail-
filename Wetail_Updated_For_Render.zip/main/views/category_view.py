from django.shortcuts import render, get_object_or_404
from .models import Category, Product

def category_view(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    products = Product.objects.filter(category=category)

    # Show a default message if no products exist in this category
    no_products_message = None
    if not products.exists():
        no_products_message = "There are no products available here. Please check back as we are continuously partnering with new vendors."

    return render(request, "category.html", {
        "category": category,
        "products": products,
        "no_products_message": no_products_message
    })
