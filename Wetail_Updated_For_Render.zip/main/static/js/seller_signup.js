console.log("seller signup attached successfully")
}