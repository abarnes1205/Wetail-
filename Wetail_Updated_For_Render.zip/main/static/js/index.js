console.log('index.js attached succesfully')
const carousel = document.querySelector('.carousel');
const children = document.querySelectorAll('.index');
var page_scroll = 0;

function page(child) {
    const index = Array.from(children).indexOf(child);
    carousel.scrollTo(index * carousel.clientWidth, 0);
}
carousel.addEventListener('scroll', e => {
    page_scroll = Math.ceil(carousel.scrollLeft / carousel.clientWidth);
    children.forEach(e => {
        e.classList.remove('active');
    });
    console.log(page_scroll)
    children.item(page_scroll).classList.add('active');
})
carousel.addEventListener("wheel", e => {

    if (e.deltaY > 0) {
        carousel.scrollBy(carousel.clientWidth, 0)
    } else {
        carousel.scrollBy(-carousel.clientWidth, 0)
    }
})