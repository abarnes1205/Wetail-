console.log("Product JS is connnected ")
let prod_id = document.getElementById('product-container').dataset.id
let data = {}
var seconds = 0
var countdownTimer
var dayContainer = document.getElementById("day")
var hourContainer = document.getElementById("hour")
var minuteContainer = document.getElementById("minute")
var secondContainer = document.getElementById("seconds")



function timer() {
    var days = Math.floor(seconds / 24 / 60 / 60);
    var hoursLeft = Math.floor((seconds) - (days * 86400));
    var hours = Math.floor(hoursLeft / 3600);
    var minutesLeft = Math.floor((hoursLeft) - (hours * 3600));
    var minutes = Math.floor(minutesLeft / 60);
    var remainingSeconds = seconds % 60;

    function pad(n) {
        return (n < 10 ? "0" + n : n);
    }
    document.getElementById('countdown').innerHTML = pad(days) + "days : " + pad(hours) + "hours : " + pad(minutes) + "minutes : " + pad(remainingSeconds) + "seconds";
    // dayContainer.innerHTML = day
    // hourContainer.innerHTML = hour
    // minuteContainer.innerHTML = minutes
    // secondContainer.innerHTML = remainingSeconds
    if (seconds == 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "Completed";
    } else {
        seconds--;
    }
}
fetch(`/get-time-period/${prod_id}/`, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    mode: 'cors', // no-cors, *cors, same-origin
    cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
        'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: 'follow', // manual, *follow, error
    referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    body: JSON.stringify(data) // body data type must match "Content-Type" header
}).then(res_json => res_json.json()).then(res => {
    if (res.status) {
        message = res.message
            // time = secondsToDhms(parseInt(message))
        upgradeTime = parseInt(message)
        seconds = upgradeTime;
        countdownTimer = setInterval('timer()', 1000);

        // notyf.success(time);
    } else {
        notyf.error(res.message);
    }
});